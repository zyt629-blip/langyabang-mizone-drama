---
name: denghong-marked-image-edit
description: 根据用户在图片上的画线、圈选、箭头或文字说明修改指定区域，并保持未标记区域、主体身份、构图和风格稳定。
---

# 灯虹画线局部修改

## 输入要求

需要一张带有明确标记的图片，以及用户对目标修改的说明。标记含义不清时调用 ask_user，提供保留、替换、删除和扩展等互斥选项。

## 区域解析

1. 记录图片资产标识。
2. 识别画线、圈选、箭头和涂抹覆盖的目标区域。
3. 明确用户要增加、删除、替换、修复或调整的内容。
4. 将标记区域之外的主体、构图、光线、材质和风格设为固定项。

## 执行流程

1. 调用 read 读取 skill://denghong-marked-image-edit/references/edit-guide.md。
2. 编译局部修改提示词，清楚描述目标区域和预期结果。
3. 调用 image_generate，将原图资产标识传入 image_asset_ids。
4. 检查修改是否只影响目标区域，画线痕迹是否消失。
5. 调用 read 读取 skill://denghong-marked-image-edit/references/quality-checks.md。
6. 出现全图重绘、主体变化或标记残留时重试一次。

## 交付

交付修改后图片、修改摘要、图片资产标识和非目标区域保持结论。
