---
name: denghong-scene-consistency
description: 根据一张场景参考图扩展同一空间的其他角度、景别或连续背景图，保持建筑结构、固定陈设、材质、时间与光源一致。
---

# 灯虹场景一致性扩展

## 输入处理

1. 获取场景参考图资产标识。
2. 识别空间边界、中心轴、入口、门窗、道路、固定陈设、材质、色彩和光源。
3. 提取用户要求的新机位、新景别或观察方向。
4. 用户没有指定扩展方向时调用 ask_user，提供反向、左侧、右侧、近景和远景等选项。

## 执行流程

1. 调用 read 读取 skill://denghong-scene-consistency/references/continuity-guide.md。
2. 建立场景固定项和允许变化项。
3. 编译只改变机位或景别的提示词。
4. 调用 image_generate，将原图资产标识传入 image_asset_ids。
5. 检查新图与原图的空间连接、结构、材质、时间和光源。
6. 调用 read 读取 skill://denghong-scene-consistency/references/quality-checks.md。
7. 出现场景重构、固定物漂移或风格变化时重试一次。

## 交付

交付扩展场景图、机位说明、图片资产标识和连续性结论。
