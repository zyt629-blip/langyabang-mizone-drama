---
name: denghong-storyboard-maker
description: 根据用户故事生成九格连续故事板。用户没有提供故事时不补写剧情，而是根据人物图片生成静态角色概念板，或根据产品与道具图片生成静态资产概念板。
---

# 灯虹故事板生成

## 类型判断

1. 用户提供明确故事、剧情梗概或连续事件时生成九格故事板。
2. 用户没有故事且提供人物图片时生成静态角色概念板。
3. 用户没有故事且提供产品或道具图片时生成静态资产概念板。
4. 图片同时含人物和产品时，调用 ask_user 让用户选择人物概念板或资产概念板。
5. 没有故事也没有图片时，调用 ask_user 让用户选择上传人物、上传资产或输入故事。

## 九格故事板流程

1. 调用 read 读取 skill://denghong-storyboard-maker/references/storyboard-guide.md。
2. 将故事压缩为九个有因果关系的关键节点。
3. 为每格确定景别、机位、动作、表情、环境和连续关系。
4. 有参考图时将图片资产标识传入 image_generate 的 image_asset_ids。
5. 设置 aspect_ratio 为 16:9，生成九格故事板。

## 无故事流程

1. 调用 read 读取 skill://denghong-storyboard-maker/references/concept-board-guide.md。
2. 只分析输入主体，不设计事件、冲突、动作发展或结局。
3. 人物图片生成角色主视觉、多角度、表情、服装材质和自然姿态。
4. 产品图片生成主视觉、多角度、结构、材质、部件和静态应用状态。
5. 调用 image_generate 并传入参考图资产标识。

## 检查

调用 read 读取 skill://denghong-storyboard-maker/references/quality-checks.md。检查画格数量、主体身份、结构、服装、场景和光线一致性。出现缺格、换脸、结构漂移或错误叙事时只重试一次。

## 交付

交付生成类型、最终图片资产、图片资产标识和检查结论。
